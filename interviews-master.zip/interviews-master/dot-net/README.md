# .NET Coding and Thinking Challenges

Microsoft .NET based at home tests for engineering interviews.

Steps:

- Fork this repo
- Modify the code as described in the README.md or Instructions.txt files inside the different folders.
- Send a pull request for your fork when you consider the assignment complete.

