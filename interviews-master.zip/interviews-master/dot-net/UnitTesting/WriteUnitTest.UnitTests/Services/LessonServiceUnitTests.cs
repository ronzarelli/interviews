﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WriteUnitTest.UnitTests.Services
{
    [TestClass]
    public class LessonServiceUnitTests
    {
        [TestMethod]
        public void UpdateLessonGrade_Test()
        {
        }
    }
}