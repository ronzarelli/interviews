# interviews
This is a set of coding challenges designed to vet the technical ability of software engineers applying to Elsevier.
