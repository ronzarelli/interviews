package com.elsevier.education;

/**

TODO Is Counter thread-safe? If so, why, and if not, how can we fix it?

none of this is thread safe.  register increment does run in one clock cycle, but you have to get the result back and forth to memory, and that blows it. similar problem with reset.

as it sits, "volatile" may an issue.  if only one thread could call increment() or reset at once, volatile guarantees that multiple readers would get the right number.

if you can have multiple writers, you need AtomicInteger or the fancy concurrency stuff...or, less efficient, do your own synchronizing.

*/
public class Exercise4 {

	public static class Counter {
		
		private int count = 0;
		
		public int increment() {
			return ++count;
		}
		
		public int getCount() {
			return count;
		}
		
		public void resetCount() {
			count = 0;
		}

	}
}