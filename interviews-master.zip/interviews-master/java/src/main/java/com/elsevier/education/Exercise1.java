package com.elsevier.education;

import java.util.Set;

/**

TODO: Make this class immutable.

*/
/* 
depends what you mean by "class".  you can declare the class "Exercise 1" final, but that covers only the basic structure.  if what you mean includes making the individual class member variables immutable, you can do them one at a time.  "phoneNumbers" is a bit tricky; making the variable final just means you can't assign a new set, but you could still change the set itself.  there are collections designed not to be changable, but them you'd have to change.
 
*/
public class Exercise1 {

	public static class Person {
		
		private Set<String> phoneNumbers;
		private String firstName;
		private String lastName;
		
		public Person() {
		}

		public Set<String> getPhoneNumbers() {
			return phoneNumbers;
		}
		public void setPhoneNumbers(Set<String> newPhoneNumbers) {
			phoneNumbers = newPhoneNumbers;
		}
		
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String newName) {
			firstName = newName;
		}
		
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String newName) {
			lastName = newName;
		}
	}
}